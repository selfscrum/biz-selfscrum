---
title: "Derick Barker"
image: "images/author/derick.jpg"
email: "sojon.themefisher@gmail.com"
social:
  - icon : "lab la-linkedin-in"
    name: "linkedin"
    link : "#!"
  - icon : "lab la-twitter"
    name: "twitter"
    link : "#!"
---

Facilis architecto quis maxime nam at, optio harum a velit nulla repellat ad culpa dolorem ab ducimus, porro enim fugit incidunt expedita. Caut repudiandae a assumenda tempora!