---
title : "Choisissez le prix"
description : "this is meta description"
layout : "pricing"
offer : "Économisez 50% sur l'abonnement annuel"
# you can set only monthly, only yearly, or toggle both
monthly_yearly_toggle: "toggle" # available value "monthly"/"yearly"/"toggle"
draft : false


# pricing card
pricing_card:
# pricing table
- name : "Essentiel"
  content : "Nam ex Magnam ratione corporis harum minus quae laudantium, ullam quaerat Illum"
  currency: "$"
  monthly_price : "39"
  yearly_price : "139"
  featured : false
  button_label : "Saisissez cette offre"
  button_link : "#"
  services:
  - "Track Reward Part Program"
  - "Design and prototype powerful"
  - "Keep work in unlimited storage"
  - "Add people document handoff."
  
# pricing table
- name : "Équipe"
  content : "Sed a ratione nemo adipisci doloribus quisquam aut sapiente quibusdam illum debitis."
  currency: "$"
  monthly_price : "99"
  yearly_price : "199"
  featured : true
  button_label : "Saisissez cette offre"
  button_link : "#"
  services:
  - "Track Reward Part Program"
  - "Design and prototype powerful"
  - "Keep work in unlimited storage"
  - "Add people document handoff."
  
# pricing table
- name : "Professionnelle"
  content : "Iusto optio voluptatem numquam natus totam ea vero minus nihil libero non!"
  currency: "$"
  monthly_price : "129"
  yearly_price : "229"
  featured : false
  button_label : "Saisissez cette offre"
  button_link : "#"
  services:
  - "Track Reward Part Program"
  - "Design and prototype powerful"
  - "Keep work in unlimited storage"
  - "Add people document handoff."
---