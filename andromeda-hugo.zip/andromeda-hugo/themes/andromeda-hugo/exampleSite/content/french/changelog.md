---
title: "Journal des modifications"
date: "2021-07-16"
layout: "changelog"
draft: false

description: "Nous recherchons un professionnel de la planification financière personnelle (planificateur financier certifié ™ <br> préféré) qui dirigera nos efforts de conseil client. Vous serez un fiduciaire qui travaillera avec"
---

#### v1.0.4 (January 19,2020)
{{< changelog >}}
{{< badge type="changed" >}}
* Enhance or improve [User experience](#!), our Site, or our Service.
* Process transactions.
* Send emails about our [Site or respond to](#!) inquiries.
* Send emails and updates about Conclude, including news and requests for agreement to amended [legal documents](#!) such
* Perform any other function that we believe in [proper functioning](#!) of our Site.

{{< badge type="added" >}}
* Including about Conclude [Site or respond to](#!) inquiries.
* Function that we believe in [proper functioning](#!) of our Site.
* News and requests for agreement Process transactions.

This is the start of dummy description text. You can change it whenever you want. This is the start of dummy description text. You can change it whenever you want. 
{{</ changelog >}}

#### v1.0.3 (October 23,2019)
{{< changelog >}}
{{< badge type="changed" >}}
* Enhance or improve [User experience](#!), our Site, or our Service.
* Process transactions.
* Send emails about our [Site or respond to](#!) inquiries.
* Send emails and updates about Conclude, including news and requests for agreement to amended [legal documents](#!) such
* Perform any other function that we believe in [proper functioning](#!) of our Site.

{{< badge type="added" >}}
* Including about Conclude [Site or respond to](#!) inquiries.
* Function that we believe in [proper functioning](#!) of our Site.
* News and requests for agreement Process transactions.
{{</ changelog >}}

#### v1.0.2 (May 19,2019)
{{< changelog >}}
{{< badge type="changed" >}}
* Enhance or improve [User experience](#!), our Site, or our Service.
* Process transactions.
* Send emails about our [Site or respond to](#!) inquiries.
* Send emails and updates about Conclude, including news and requests for agreement to amended [legal documents](#!) such
* Perform any other function that we believe in [proper functioning](#!) of our Site.

{{< badge type="added" >}}
* Including about Conclude [Site or respond to](#!) inquiries.
* Function that we believe in [proper functioning](#!) of our Site.
* News and requests for agreement Process transactions.
{{</ changelog >}}

#### v1.0.1 (March 15,2019)
{{< changelog >}}
{{< badge type="depreciate" >}}
* Enhance or improve [User experience](#!), our Site, or our Service.
* Process transactions.
* Send emails about our [Site or respond to](#!) inquiries.
* Send emails and updates about Conclude, including news and requests for agreement to amended [legal documents](#!) such
* Perform any other function that we believe in [proper functioning](#!) of our Site.

{{< badge type="security" >}}
* Including about Conclude [Site or respond to](#!) inquiries.
* Function that we believe in [proper functioning](#!) of our Site.
* News and requests for agreement Process transactions.
{{</ changelog >}}

#### v1.0 (January 01,2019)
{{< changelog >}}
{{< badge type="removed" >}}
* Enhance or improve [User experience](#!), our Site, or our Service.
* Process transactions.
* Send emails about our [Site or respond to](#!) inquiries.
* Send emails and updates about Conclude, including news and requests for agreement to amended [legal documents](#!) such
* Perform any other function that we believe in [proper functioning](#!) of our Site.

{{< badge type="security" >}}
* Including about Conclude [Site or respond to](#!) inquiries.
* Function that we believe in [proper functioning](#!) of our Site.
* News and requests for agreement Process transactions.
{{</ changelog >}}