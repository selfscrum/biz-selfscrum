## Version 1.0.0 (10 aug 2021)
- Initial template
- Hugo version 0.56.1
- Bootstrap version v4.5.0

## Version 1.1.0 (15 aug 2021)
- Hugo version 0.87
- Added Pricing Page
- Updated Navigation active menu
- Updated Logo and favicon
- Updated forestry setting
- Updated i18n
- Updated video styled

## Version 1.1.1 (17 aug 2021)
- Updated wave-lines
- Updated colors issues

## Version 1.1.2 (15 nov 2021)
- Updated header and menu